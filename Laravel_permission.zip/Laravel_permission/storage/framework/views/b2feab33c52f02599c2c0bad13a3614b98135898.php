<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8 offset-2" style="margin-top: 20px;">
                <div class="alert alert-info">
                    <h2 style="text-align: center">Posts</h2>
                    <br>
                    <div class="alert alert-dark">
                        <h3>User : <?php echo e(auth()->user()->name); ?></h3>
                        <br>

                        <a href="<?php echo e(route('user.logout')); ?>">Logout</a>
                    </div>
                </div>
                <?php if(empty($datas)): ?>
                    No data
                <?php else: ?>

                    
                    
                        
                    

                
                <?php if(auth()->user()->can('write post')): ?>
                    <a href="<?php echo e(route('article.create')); ?>">New</a>
                    <?php endif; ?>
                    <ul>
                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="">
                                <h5 class=""><?php echo e($data->title); ?>

                                    <?php if(auth()->user()->can('edit post')): ?>
                                        <a href="<?php echo e(route('article.edit', $data->id)); ?>">Edit</a></h5>
                                    <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Documents/Laravel/Laravel_permission/resources/views/posts.blade.php ENDPATH**/ ?>