<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    
    <link rel="stylesheet" href="<?php echo e(url('css/bs/bs.min.css')); ?>">


    <script src="<?php echo e(url('js/jq.j')); ?>"></script>


</head>

<?php echo $__env->yieldContent('style'); ?>

<body>
<?php $__env->startSection('content'); ?>
<?php echo $__env->yieldSection(); ?>


</body>
</html>
<?php $__env->startSection('script'); ?>
<?php echo $__env->yieldSection(); ?><?php /**PATH /Users/mac/Documents/Laravel/Laravel_permission/resources/views/layouts/master.blade.php ENDPATH**/ ?>